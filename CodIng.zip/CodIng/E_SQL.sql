CREATE DATABASE biblioteca;
USE biblioteca;
CREATE TABLE libros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    autor VARCHAR(255) NOT NULL,
    isbn VARCHAR(50) NOT NULL,
    estado_prestamo VARCHAR(50) NOT NULL DEFAULT 'Disponible'
);
INSERT INTO libros (titulo, autor, isbn, estado_prestamo) VALUES
('Cien años de soledad', 'Gabriel García Márquez', '978-0307474728', 'Disponible'),
('1984', 'George Orwell', '978-0451524935', 'Prestado'),
('El principito', 'Antoine de Saint-Exupéry', '978-1542004244', 'Disponible'),
('Don Quijote de la Mancha', 'Miguel de Cervantes', '978-8420412146', 'Disponible'),
('Crónica de una muerte anunciada', 'Gabriel García Márquez', '978-1400034956', 'Prestado');