<?php
defined('BASEPATH') OR exit('bro?');

class Libros_mod extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    public function get_libros() {
        $query = $this->db->get('libros');
        return $query->result_array();

    }
    public function get_libro_por_id($id) {
        $query = $this->db->get_where('libros', array('id' => $id));
        return $query->row_array();
    }
    public function insertar_libro($data) {
        return $this->db->insert('libros', $data);
    }
    public function actualizar_libro($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('libros', $data);
    }
    public function eliminar_libro($id) {
        $this->db->where('id', $id);
        return $this->db->delete('libros');
    }
}