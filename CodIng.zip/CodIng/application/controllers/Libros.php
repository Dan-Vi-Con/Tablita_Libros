<?php
defined('BASEPATH') OR exit('controlador_no_fount_XD');

class Libros extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Libros_mod');
        $this->load->helper('url');
    }

    public function index() {
        $data['libros'] = $this->Libros_mod->get_libros();
        $this->load->view('libros/index', $data);
    }

    public function crear() {
        $this->load->view('libros/crear');
    }

    public function guardar() {
        $data = array(
            'titulo'          => $this->input->post('titulo'),
            'autor'           => $this->input->post('autor'),
            'isbn'            => $this->input->post('isbn'),
            'estado_prestamo' => $this->input->post('estado_prestamo')
        );

        $this->Libros_mod->insertar_libro($data);
        header("Location: http://localhost:8080/CodIng/index.php/libros");
        exit();
    }

    public function editar($id) {
        $data['libro'] = $this->Libros_mod->get_libro_por_id($id);
        $this->load->view('libros/editar', $data);
    }

    public function actualizar($id) {
        $data = array(
            'titulo'          => $this->input->post('titulo'),
            'autor'           => $this->input->post('autor'),
            'isbn'            => $this->input->post('isbn'),
            'estado_prestamo' => $this->input->post('estado_prestamo')
        );

        $this->Libros_mod->actualizar_libro($id, $data);
        header("Location: http://localhost:8080/CodIng/index.php/libros");
        exit();
    }

    public function eliminar($id) {
        $this->Libros_mod->eliminar_libro($id);
        header("Location: http://localhost:8080/CodIng/index.php/libros");
        exit();
    }
}