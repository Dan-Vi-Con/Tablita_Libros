<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Añadir Libro</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body style="background-color: #000000;" class="text-white">

    <div class="container mt-4" style="max-width: 500px;">
        <h2>Registrar Libro</h2>
        <br>
        <form action="http://localhost:8080/CodIng/index.php/libros/guardar" method="POST">
            
            <div class="form-group">
                <label>Título:</label>
                <input type="text" name="titulo" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Autor:</label>
                <input type="text" name="autor" class="form-control" required>
            </div>

            <div class="form-group">
                <label>ISBN:</label>
                <input type="text" name="isbn" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Estado de Préstamo:</label>
                <select name="estado_prestamo" class="form-control">
                    <option value="Disponible">Disponible</option>
                    <option value="Prestado">Prestado</option>
                    <option value="En Reparación">En Reparación</option>
                </select>
            </div>

            <button type="submit" class="btn btn-dark">Guardar</button>
            <a href="http://localhost:8080/CodIng/index.php/libros" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>

</body>
</html>