<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Libros</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body style="background-color: #000000;" class="text-white">
    <div class="container mt-4">
        <center>
            <h2>Gestion Biblioteca</h2>
        </center>
        <h3>Tablita de Libros</h3>
        <table class="table table-dark table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Título</th>
                    <th>Autor</th>
                    <th>ISBN</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($libros) > 0) { ?>
                    <?php foreach ($libros as $libro) { ?>
                    <tr>
                        <td><?php echo $libro['id']; ?></td>
                        <td><?php echo $libro['titulo']; ?></td>
                        <td><?php echo $libro['autor']; ?></td>
                        <td><?php echo $libro['isbn']; ?></td>
                        <td><?php echo $libro['estado_prestamo']; ?></td>
                        <td>
                            <a href="http://localhost:8080/CodIng/index.php/libros/editar/<?php echo $libro['id']; ?>" class="btn btn-dark btn-sm">Editar</a>
                            <a href="http://localhost:8080/CodIng/index.php/libros/eliminar/<?php echo $libro['id']; ?>" class="btn btn-dark btn-sm">Eliminar</a>
                        </td>
                    </tr>
                    <?php } ?>
                <?php } else { ?>
                    <tr>
                        <td colspan="6" class="text-center">nada chavito</td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <a href="http://localhost:8080/CodIng/index.php/libros/crear" class="btn btn-dark mb-3">Añadir Libro</a>
    </div>

</body>
</html>